#import <Flutter/Flutter.h>

@interface InstallPlugin : NSObject<FlutterPlugin>
@end
